plugins {
    id("java")
}

group = "org.utbot.ifds.synthetic.tests"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}