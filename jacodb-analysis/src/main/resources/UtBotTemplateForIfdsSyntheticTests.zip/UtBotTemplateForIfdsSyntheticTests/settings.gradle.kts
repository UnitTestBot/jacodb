rootProject.name = "UtBotTemplateForIfdsSyntheticTests"

